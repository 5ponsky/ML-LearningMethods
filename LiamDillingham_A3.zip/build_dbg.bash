#!/bin/bash
set -e -v
echo "Compiling..."
javac -g *.java
echo "To run: java Main"
